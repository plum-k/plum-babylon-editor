/**
 * Represents a texture handle for the backbuffer color texture.
 */
export const backbufferColorTextureHandle = 0;
/**
 * Represents a texture handle for the backbuffer depth/stencil texture.
 */
export const backbufferDepthStencilTextureHandle = 1;
//# sourceMappingURL=frameGraphTypes.js.map