/**
 * Structure used by the frame graph to reference objects.
 * @experimental
 */
export class FrameGraphObjectList {
}
//# sourceMappingURL=frameGraphObjectList.js.map