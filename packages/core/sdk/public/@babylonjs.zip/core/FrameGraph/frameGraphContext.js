/**
 * Base class for frame graph context.
 */
export class FrameGraphContext {
}
//# sourceMappingURL=frameGraphContext.js.map