/**
 * @internal
 **/
// eslint-disable-next-line @typescript-eslint/naming-convention
export class _TimeToken {
    constructor() {
        this._timeElapsedQueryEnded = false;
    }
}
//# sourceMappingURL=timeToken.js.map