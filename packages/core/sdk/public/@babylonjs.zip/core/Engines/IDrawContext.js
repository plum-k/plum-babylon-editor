export {};
//# sourceMappingURL=IDrawContext.js.map