/* eslint-disable @typescript-eslint/no-unused-vars */
import { AbstractEngine } from "../../Engines/abstractEngine.js";
AbstractEngine.prototype._debugPushGroup = function (groupName, targetObject) { };
AbstractEngine.prototype._debugPopGroup = function (targetObject) { };
AbstractEngine.prototype._debugInsertMarker = function (text, targetObject) { };
AbstractEngine.prototype._debugFlushPendingCommands = function () { };
//# sourceMappingURL=engine.debugging.js.map