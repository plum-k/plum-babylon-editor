export {};
//# sourceMappingURL=instancingAttributeInfo.js.map