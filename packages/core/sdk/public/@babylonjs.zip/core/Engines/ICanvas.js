export {};
//# sourceMappingURL=ICanvas.js.map