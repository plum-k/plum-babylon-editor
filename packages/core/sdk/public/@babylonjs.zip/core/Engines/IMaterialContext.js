export {};
//# sourceMappingURL=IMaterialContext.js.map