export {};
//# sourceMappingURL=IBoundingInfoHelperPlatform.js.map