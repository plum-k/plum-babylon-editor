export {};
//# sourceMappingURL=ISkeletonViewer.js.map