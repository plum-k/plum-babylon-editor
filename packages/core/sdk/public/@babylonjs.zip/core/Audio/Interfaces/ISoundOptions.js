export {};
//# sourceMappingURL=ISoundOptions.js.map