export {};
//# sourceMappingURL=deviceTypes.js.map