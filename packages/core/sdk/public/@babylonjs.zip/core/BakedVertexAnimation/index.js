export * from "./bakedVertexAnimationManager.js";
export * from "./vertexAnimationBaker.js";
//# sourceMappingURL=index.js.map